from setuptools import setup

setup(name='baseplots',
      version='0.1',
      description='standardized plots from matplotlib and seaborn',
      packages=['baseplots'],
      zip_safe=False)
